/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package caffee;

import code.Dao;
import code.ThanhToan;
import code.TinhToan;
import java.awt.Color;
import java.awt.print.PrinterException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hello
 */
public class Don_Hang extends javax.swing.JFrame {

     int xx, xy;
     Dao dao = new Dao();
     DefaultTableModel model;
     int rowIndex;
     private Double TongTien = 0.0;
     LocalDate curDate = LocalDate.now();
     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
     TinhToan tinhToan = new TinhToan();
     
     
     

     public Don_Hang() {
          initComponents();
          init();
     }
     
     private void init(){
          jTextField1.setText(String.valueOf(dao.getMaxRowThanhToanTable()));
          jTextField2.setText(curDate.format(formatter));
          jTextField4.setText(String.valueOf(dao.TongPhu()));
          tinhToan.setTongPhu(Double.parseDouble(jTextField4.getText()));
          jTextField3.setText(String.valueOf(tinhToan.getThue()));
          jTextField5.setText(String.valueOf(tinhToan.getTong()));
          bangSanPham();
     }

     private void bangSanPham() {
          dao.getGioHangSanPham(jTable1);
          model = (DefaultTableModel) jTable1.getModel();
          jTable1.setRowHeight(100);
          jTable1.setShowGrid(true);
          jTable1.setGridColor(Color.BLACK);
          jTable1.setBackground(Color.WHITE);
          jTable1.setSelectionBackground(Color.gray);
          jTable1.setModel(model);
     } 
     @SuppressWarnings("unchecked")
     // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
     private void initComponents() {

          jPanel1 = new javax.swing.JPanel();
          jLabel4 = new javax.swing.JLabel();
          jScrollPane1 = new javax.swing.JScrollPane();
          jTable1 = new javax.swing.JTable();
          jLabel2 = new javax.swing.JLabel();
          jTextField1 = new javax.swing.JTextField();
          jLabel3 = new javax.swing.JLabel();
          jTextField2 = new javax.swing.JTextField();
          jLabel5 = new javax.swing.JLabel();
          jTextField3 = new javax.swing.JTextField();
          jButton2 = new javax.swing.JButton();
          jLabel6 = new javax.swing.JLabel();
          jLabel7 = new javax.swing.JLabel();
          jLabel8 = new javax.swing.JLabel();
          jLabel9 = new javax.swing.JLabel();
          jTextField4 = new javax.swing.JTextField();
          jTextField5 = new javax.swing.JTextField();
          jTextField6 = new javax.swing.JTextField();
          jTextField7 = new javax.swing.JTextField();
          jLabel10 = new javax.swing.JLabel();
          jTextField8 = new javax.swing.JTextField();

          setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
          setUndecorated(true);
          addWindowListener(new java.awt.event.WindowAdapter() {
               public void windowOpened(java.awt.event.WindowEvent evt) {
                    formWindowOpened(evt);
               }
          });

          jPanel1.setBackground(new java.awt.Color(158, 111, 78));
          jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
               public void mouseDragged(java.awt.event.MouseEvent evt) {
                    jPanel1MouseDragged(evt);
               }
          });
          jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mousePressed(java.awt.event.MouseEvent evt) {
                    jPanel1MousePressed(evt);
               }
          });

          jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
          jLabel4.setForeground(new java.awt.Color(255, 255, 255));
          jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
          jLabel4.setText("X");
          jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    jLabel4MouseClicked(evt);
               }
          });

          jTable1.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Mã Thanh Toán", "Mã Sản Phẩm", "Tên Sản Phẩm", "Số Lượng", "Giá Tiền", "Tổng"
               }
          ));
          jScrollPane1.setViewportView(jTable1);

          jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel2.setForeground(new java.awt.Color(255, 255, 255));
          jLabel2.setText("Ngày Thanh Toán :");

          jTextField1.setBackground(new java.awt.Color(204, 204, 204));
          jTextField1.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

          jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel3.setForeground(new java.awt.Color(255, 255, 255));
          jLabel3.setText("Mã Hóa Đơn :");

          jTextField2.setBackground(new java.awt.Color(204, 204, 204));
          jTextField2.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N

          jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel5.setForeground(new java.awt.Color(255, 255, 255));
          jLabel5.setText("Thuế (VNĐ) :");

          jTextField3.setEditable(false);
          jTextField3.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
          jTextField3.setHorizontalAlignment(javax.swing.JTextField.LEFT);

          jButton2.setBackground(new java.awt.Color(237, 226, 219));
          jButton2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
          jButton2.setText("Thanh Toán");
          jButton2.addActionListener(new java.awt.event.ActionListener() {
               public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
               }
          });

          jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel6.setForeground(new java.awt.Color(255, 255, 255));
          jLabel6.setText("Tổng Cộng (VNĐ) :");

          jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel7.setForeground(new java.awt.Color(255, 255, 255));
          jLabel7.setText("Tổng Phụ (VNĐ): ");

          jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel8.setForeground(new java.awt.Color(255, 255, 255));
          jLabel8.setText("Khách trả (Tiền mặt) :");

          jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel9.setForeground(new java.awt.Color(255, 255, 255));
          jLabel9.setText("Tên Khách Hàng :");

          jTextField4.setEditable(false);
          jTextField4.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
          jTextField4.setHorizontalAlignment(javax.swing.JTextField.LEFT);

          jTextField5.setEditable(false);
          jTextField5.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
          jTextField5.setHorizontalAlignment(javax.swing.JTextField.LEFT);

          jTextField6.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
          jTextField6.setHorizontalAlignment(javax.swing.JTextField.LEFT);

          jTextField7.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
          jTextField7.setHorizontalAlignment(javax.swing.JTextField.LEFT);
          jTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
               public void keyReleased(java.awt.event.KeyEvent evt) {
                    jTextField7KeyReleased(evt);
               }
          });

          jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
          jLabel10.setForeground(new java.awt.Color(255, 255, 255));
          jLabel10.setText("Tiền Thừa (VNĐ) :");

          jTextField8.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
          jTextField8.setHorizontalAlignment(javax.swing.JTextField.LEFT);
          jTextField8.addActionListener(new java.awt.event.ActionListener() {
               public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jTextField8ActionPerformed(evt);
               }
          });
          jTextField8.addKeyListener(new java.awt.event.KeyAdapter() {
               public void keyReleased(java.awt.event.KeyEvent evt) {
                    jTextField8KeyReleased(evt);
               }
          });

          javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
          jPanel1.setLayout(jPanel1Layout);
          jPanel1Layout.setHorizontalGroup(
               jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(14, 14, 14)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                   .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                             .addComponent(jLabel3)
                                             .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jLabel2)
                                             .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jLabel5)
                                             .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jLabel6)
                                             .addComponent(jLabel7)
                                             .addComponent(jLabel8)
                                             .addComponent(jLabel9)
                                             .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jLabel10))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE))
                                   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                              .addContainerGap())
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                              .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addGap(124, 124, 124))))
          );
          jPanel1Layout.setVerticalGroup(
               jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                              .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                              .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addGap(34, 34, 34))))
          );

          javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
          getContentPane().setLayout(layout);
          layout.setHorizontalGroup(
               layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
          );
          layout.setVerticalGroup(
               layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
          );

          pack();
          setLocationRelativeTo(null);
     }// </editor-fold>//GEN-END:initComponents

     private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
          // TODO add your handling code here:
          setVisible(false);
     }//GEN-LAST:event_jLabel4MouseClicked

     private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
          // TODO add your handling code here:
     }//GEN-LAST:event_jTextField8ActionPerformed

     private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
          xx = evt.getX();
          xy = evt.getY();
     }//GEN-LAST:event_jPanel1MousePressed

     private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
          int x = evt.getXOnScreen();
          int y = evt.getYOnScreen();
          this.setLocation(x - xx, y - xy);
     }//GEN-LAST:event_jPanel1MouseDragged

     private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
          for (double i = 0.1; i < 1.0; i += 0.1) {
               String s = "" + i;
               float f = Float.parseFloat(s);
               this.setOpacity(f);
               try {
                    Thread.sleep(40);
               } catch (InterruptedException ex) {
                    Logger.getLogger(Don_Hang.class.getName()).log(Level.SEVERE, null, ex);
               }
          }
     }//GEN-LAST:event_formWindowOpened

     private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          model = (DefaultTableModel) jTable1.getModel();
          String proName = "";
          String proId = "";
          for(int i = 0 ; i < model.getRowCount() ; i++){
               proId += model.getValueAt(i, 1).toString()+", ";
               proName += model.getValueAt(i, 2).toString()+", ";
          }
          int pid = dao.getMaxRowThanhToanTable() + 1;
          String cName = jTextField6.getText().trim();
          double t = Double.parseDouble(jTextField5.getText().trim());
          
          ThanhToan thanhToan = new ThanhToan();
          thanhToan.setPid(pid);          
          thanhToan.setcName(cName);
          thanhToan.setProId(proId);
          thanhToan.setProName(proName);
          thanhToan.setTongTien(t);
          thanhToan.setNgay(jTextField2.getText().trim());
          if(check()){
               if(dao.ThemThanhToan(thanhToan)){
                    JOptionPane.showMessageDialog(this,"Thanh Toán Thành Công");
                    int cid = Integer.parseInt(model.getValueAt(rowIndex, 0).toString());
                    dao.XoaCart(cid);
                    int x = JOptionPane.showConfirmDialog(this, "Bạn có muốn in hóa đơn không" , "In" , JOptionPane.YES_NO_OPTION , 0);
                    if( x == JOptionPane.YES_OPTION){
                         printHoaDonBangTextPane();
                         setVisible(false);
                    }else {
                         setVisible(false);
                    }
               }else {
                    JOptionPane.showMessageDialog(this, "Thanh toán thất bại...","Cảnh báo",2);
               }      
          } 
     }//GEN-LAST:event_jButton2ActionPerformed

     private void jTextField8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField8KeyReleased
          
     }//GEN-LAST:event_jTextField8KeyReleased

     private void jTextField7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField7KeyReleased
          tienmat();
     }//GEN-LAST:event_jTextField7KeyReleased

     private void printHoaDonBangTextPane() {
    JTextPane textPane = new JTextPane();
    textPane.setContentType("text/html");
    String customerName = jTextField6.getText().trim();
    String ngay = jTextField2.getText().trim();
    double tongTien = Double.parseDouble(jTextField5.getText().trim());
    DecimalFormat df = new DecimalFormat("#,###.##");
    String tongTienFormatted = df.format(tongTien);
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    StringBuilder html = new StringBuilder();
    html.append("<html><body style='font-family:Arial;'>");
    html.append("<h2 style='text-align:center;'>*** NHẬT NAM CAFE ***</h2>");
    html.append("<p><strong>Khách Hàng:</strong> ").append(customerName).append("</p>");
    html.append("<p><strong>Ngày:</strong> ").append(ngay).append("</p><br>");
    html.append("<table border='1' cellspacing='0' cellpadding='5' width='100%'>");
    html.append("<tr style='background-color:#f2f2f2;'>");
    html.append("<th>Mã SP</th><th>Tên SP</th><th>Số Lượng</th><th>Đơn Giá</th><th>Thành Tiền</th>");
    html.append("</tr>");
    for (int i = 0; i < model.getRowCount(); i++) {
        String maSP = model.getValueAt(i, 1).toString();
        String tenSP = model.getValueAt(i, 2).toString();
        String soLuong = model.getValueAt(i, 3).toString();
        String donGia = df.format(Double.parseDouble(model.getValueAt(i, 4).toString()));
        String thanhTien = df.format(Double.parseDouble(model.getValueAt(i, 5).toString()));

        html.append("<tr>")
            .append("<td>").append(maSP).append("</td>")
            .append("<td>").append(tenSP).append("</td>")
            .append("<td>").append(soLuong).append("</td>")
            .append("<td>").append(donGia).append("</td>")
            .append("<td>").append(thanhTien).append("</td>")
            .append("</tr>");
    }

    html.append("</table><br>");
    html.append("<h3 style='text-align:right;'>Tổng Tiền: ").append(tongTienFormatted).append(" VND</h3>");
    html.append("<p style='text-align:center;'>Cảm ơn quý khách! Hẹn gặp lại!</p>");
    html.append("</body></html>");
    textPane.setText(html.toString());
    
    try {
        boolean done = textPane.print();
        if (done) {
            JOptionPane.showMessageDialog(this, "In hóa đơn thành công!");
        } else {
            JOptionPane.showMessageDialog(this, "In bị hủy.");
        }
    } catch (PrinterException ex) {
        JOptionPane.showMessageDialog(this, "Lỗi in: " + ex.getMessage());
    }
}
     
     public void tienmat(){
          try {
             double tienmat = Double.parseDouble(jTextField7.getText().trim());
             double tongtien = Double.parseDouble(jTextField5.getText().trim());
             double change = (tienmat - tongtien);
             jTextField8.setText(String.valueOf(change));
          } catch (Exception e) {
               JOptionPane.showMessageDialog(this, "tiền mặt nhập vào không đủ" , "Cảnh Báo" , 2);
          }
     }
     public boolean check(){
          if(jTextField6.getText().isEmpty()){
               JOptionPane.showMessageDialog(this, "tên khách hàng là bắt buộc" , "Cảnh Báo" , 2);
               return false;
          }
          if(jTextField7.getText().isEmpty()){
               JOptionPane.showMessageDialog(this, "tiền mặt là cần thiết" , "Cảnh Báo" , 2);
               return false;
          }
          double change = Double.parseDouble(jTextField8.getText().trim());
          if(change < 0.0){
               JOptionPane.showMessageDialog(this, "tiền mặt nhập vào không đủ" , "Cảnh Báo" , 2);
               return false;
          }
          return true;
     }
     

     // Variables declaration - do not modify//GEN-BEGIN:variables
     private javax.swing.JButton jButton2;
     private javax.swing.JLabel jLabel10;
     private javax.swing.JLabel jLabel2;
     private javax.swing.JLabel jLabel3;
     private javax.swing.JLabel jLabel4;
     private javax.swing.JLabel jLabel5;
     private javax.swing.JLabel jLabel6;
     private javax.swing.JLabel jLabel7;
     private javax.swing.JLabel jLabel8;
     private javax.swing.JLabel jLabel9;
     private javax.swing.JPanel jPanel1;
     private javax.swing.JScrollPane jScrollPane1;
     private javax.swing.JTable jTable1;
     private javax.swing.JTextField jTextField1;
     private javax.swing.JTextField jTextField2;
     private javax.swing.JTextField jTextField3;
     private javax.swing.JTextField jTextField4;
     private javax.swing.JTextField jTextField5;
     private javax.swing.JTextField jTextField6;
     private javax.swing.JTextField jTextField7;
     private javax.swing.JTextField jTextField8;
     // End of variables declaration//GEN-END:variables
}
