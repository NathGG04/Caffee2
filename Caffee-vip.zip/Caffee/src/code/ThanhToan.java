/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;

/**
 *
 * @author Hello
 */
public class ThanhToan {
     private int pid;
     private String cName;
     private String proId;
     private String proName;
     private double TongTien;
     private String ngay;

     public int getPid() {
          return pid;
     }

     public void setPid(int pid) {
          this.pid = pid;
     }

     public String getcName() {
          return cName;
     }

     public void setcName(String cName) {
          this.cName = cName;
     }

     public String getProId() {
          return proId;
     }

     public void setProId(String proId) {
          this.proId = proId;
     }

     public String getProName() {
          return proName;
     }

     public void setProName(String proName) {
          this.proName = proName;
     }

     public double getTongTien() {
          return TongTien;
     }

     public void setTongTien(double TongTien) {
          this.TongTien = TongTien;
     }

     public String getNgay() {
          return ngay;
     }

     public void setNgay(String ngay) {
          this.ngay = ngay;
     }
     
}
