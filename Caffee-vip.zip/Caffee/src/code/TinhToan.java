/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;

/**
 *
 * @author Hello
 */
public class TinhToan {
     private double Thue;
     private double TongPhu;

     public double getThue() {
          return tinhThue(TongPhu);
     }
     
     public double getTong() {
          return TongPhu + getThue();
     }
    
     public double getTongPhu() {
          return TongPhu;
     }

     public void setTongPhu(double TongPhu) {
          this.TongPhu = TongPhu;
     }
     
     private double tinhThue(double t){
          if(t<=100000){
               Thue = 0;
          }
          else if(t>100000){
               Thue = t*0.05;
          }
          return Thue;
     }
     
}
