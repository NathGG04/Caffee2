/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;

import java.sql.Connection;
import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hello
 */
public class Dao {

     Connection con = KetNoi.getConnection();
     PreparedStatement ps;
     Statement st;
     ResultSet rs;

     public int getMaxRowSanPhamTable() {
          int row = 0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("SELECT MAX(MaSanPham) FROM sanpham");
               while (rs.next()) {
                    row = rs.getInt(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return row + 1;
     }

     public boolean themSanPham(SanPham p) {
          String sql = "INSERT INTO sanpham (MaSanPham, TenSp, GiaTien, AnhSanPham) VALUES (?, ?, ?, ?)";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, p.getMaSanPham());
               ps.setString(2, p.getTenSp());
               ps.setDouble(3, p.getGiaTien());
               ps.setBytes(4, p.getAnhSanPham());
               return ps.executeUpdate() > 0;
          } catch (Exception ex) {
               return false;
          }
     }

     public void getTatCaSanPham(JTable table) {
          String sql = "SELECT * FROM sanpham ORDER BY MaSanPham DESC";
          try {
               ps = con.prepareStatement(sql);
               rs = ps.executeQuery();
               DefaultTableModel model = (DefaultTableModel) table.getModel();
               Object[] row;

               while (rs.next()) {
                    row = new Object[4];
                    row[0] = rs.getInt(1);
                    row[1] = rs.getString(2);
                    row[2] = rs.getDouble(3);
                    row[3] = rs.getBytes(4);
                    model.addRow(row);
               }

          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

          }
     }

     public boolean CapNhat(SanPham sanpham) {
          String sql = "update sanpham set TenSp = ? ,GiaTien = ? where MaSanPham = ? ";
          try {
               ps = con.prepareStatement(sql);
               ps.setString(1, sanpham.getTenSp());
               ps.setDouble(2, sanpham.getGiaTien());
               ps.setInt(3, sanpham.getMaSanPham());
               return ps.executeUpdate() > 0;
          } catch (Exception ex) {
               return false;
          }
     }

     public boolean Xoa(SanPham sanpham) {
          String sql = "delete from sanpham where MaSanPham = ?";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, sanpham.getMaSanPham());
               return ps.executeUpdate() > 0;
          } catch (Exception ex) {
               return false;
          }
     }

     public int getMaxRowOderTable() {
          int row = 0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("SELECT MAX(cid) FROM cart");
               while (rs.next()) {
                    row = rs.getInt(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return row + 1;
     }

     public boolean isSanPhamExist(int cid, int pid) {
          String sql = "SELECT * FROM cart where cid = ? and pid =?";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, cid);
               ps.setInt(2, pid);
               rs = ps.executeQuery();
               if (rs.next()) {
                    return true;
               }

          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

          }
          return false;
     }

     public boolean insertCart(Cart cart) {
          String sql = "INSERT INTO cart (cid,pid,pName,qty,GiaTien,TongTien) VALUES (?, ?, ?, ? , ? , ?)";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, cart.getid());
               ps.setInt(2, cart.getPid());
               ps.setString(3, cart.getpName());
               ps.setInt(4, cart.getQty());
               ps.setDouble(5, cart.getGiaTien());
               ps.setDouble(6, cart.getTongTien());
               return ps.executeUpdate() > 0;
          } catch (Exception ex) {
               return false;
          }
     }

     public int getMaxRowThanhToanTable() {
          int row = 0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("SELECT MAX(pid) FROM thanhtoan");
               while (rs.next()) {
                    row = rs.getInt(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return row + 1;
     }
/*
     public int getMaxRowCartTable() {
          int row = 0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("SELECT MAX(cid) FROM cart");
               while (rs.next()) {
                    row = rs.getInt(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return row;
     }
*/
     public double TongPhu() {
          double tongPhu = 0.0;
          int cid = getMaxRowOderTable();
          try {
               st = con.createStatement();
               rs = st.executeQuery("SELECT sum(TongTien) as 'TongTien' FROM cart where cid= '" + cid + "'");
               if (rs.next()) {
                    tongPhu = rs.getDouble(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return tongPhu;

     }

     public void getGioHangSanPham(JTable table) {
          int cid = getMaxRowOderTable();
          String sql = "SELECT * FROM cart where cid =?";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, cid);
               rs = ps.executeQuery();
               DefaultTableModel model = (DefaultTableModel) table.getModel();
               Object[] row;

               while (rs.next()) {
                    row = new Object[6];
                    row[0] = rs.getInt(1);
                    row[1] = rs.getInt(2);
                    row[2] = rs.getString(3);
                    row[3] = rs.getInt(4);
                    row[4] = rs.getDouble(5);
                    row[5] = rs.getDouble(6);
                    model.addRow(row);
               }

          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

          }
     }

     public boolean ThemThanhToan(ThanhToan thanhToan) {
          String sql = "INSERT INTO thanhtoan (pid,cName,proid,pName,TongTien,pdate) VALUES (?, ?, ?, ? , ? , ?)";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, thanhToan.getPid());
               ps.setString(2, thanhToan.getcName());
               ps.setString(3, thanhToan.getProId());
               ps.setString(4, thanhToan.getProName());
               ps.setDouble(5, thanhToan.getTongTien());
               ps.setString(6, thanhToan.getNgay());

               return ps.executeUpdate() > 0;
          } catch (Exception ex) {
               return false;
          }
     }

     public boolean XoaCart(int cid) {
          String sql = "delete from cart where cid = ?";
          try {
               ps = con.prepareStatement(sql);
               ps.setInt(1, cid);
               return ps.executeUpdate() > 0;
          } catch (Exception ex) {
               return false;
          }
     }

     public void getXemDonHang(JTable table) {
          String sql = "SELECT * FROM thanhtoan order by pid desc";
          try {
               ps = con.prepareStatement(sql);
               rs = ps.executeQuery();
               DefaultTableModel model = (DefaultTableModel) table.getModel();
               Object[] row;

               while (rs.next()) {
                    row = new Object[6];
                    row[0] = rs.getInt(1);
                    row[1] = rs.getString(2);
                    row[2] = rs.getString(3);
                    row[3] = rs.getString(4);
                    row[4] = rs.getDouble(5);
                    row[5] = rs.getString(6);
                    model.addRow(row);
               }

          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);

          }
     }

     public int TongSanPham() {
          int total = 0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("select count(*) as 'total' from sanpham");
               if (rs.next()) {
                    total = rs.getInt(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return total;
     }
     public double DoanhThuNgay(String date) {
          double total = 0.0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("select sum(TongTien) as 'total' from thanhtoan where pdate = '" + date + "' ");
               if (rs.next()) {
                    total = rs.getDouble(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return total;
     }
     public double DoanhThuTong() {
          double total = 0.0;
          try {
               st = con.createStatement();
               rs = st.executeQuery("select sum(Tongtien) as 'total' from thanhtoan");
               if (rs.next()) {
                    total = rs.getDouble(1);
               }
          } catch (Exception ex) {
               java.util.logging.Logger.getLogger(Dao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
          }
          return total;
     }
}
