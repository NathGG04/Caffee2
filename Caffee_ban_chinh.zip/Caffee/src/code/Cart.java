/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;

/**
 *
 * @author Hello
 */
public class Cart {
     private int id;
     private int pid;
     private String pName;
     private int qty;
     private double GiaTien;
     private double TongTien;

     public int getid() {
          return id;
     }

     public void setid(int id) {
          this.id = id;
     }

     public int getPid() {
          return pid;
     }

     public void setPid(int pid) {
          this.pid = pid;
     }

     public String getpName() {
          return pName;
     }

     public void setpName(String pName) {
          this.pName = pName;
     }

     public int getQty() {
          return qty;
     }

     public void setQty(int qty) {
          this.qty = qty;
     }

     public double getGiaTien() {
          return GiaTien;
     }

     public void setGiaTien(double GiaTien) {
          this.GiaTien = GiaTien;
     }

     public double getTongTien() {
          return TongTien;
     }

     public void setTongTien(double TongTien) {
          this.TongTien = TongTien;
     }
     
     
     
     
}
